this is about : Variables, if, else, while
