#include "main.h"
/**
 * add - function that sum two integers
 * @a: integer to add
 * @b: integer to add
 * Return: sum of tow integers
 **/

int add(int a, int b)
{
	return (a + b);
}
