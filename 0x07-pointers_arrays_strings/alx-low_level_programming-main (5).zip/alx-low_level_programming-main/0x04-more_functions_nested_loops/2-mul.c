#include "main.h"

/**
 * mul - input
 * Description: multiplies 2 numbers
 * @a: first number
 * @b: second number
 * Return: the answer
 */

int mul(int a, int b)
{
	return (a * b);
}
